#include<iostream>
using namespace std;
 int main(){
int x;
     cin>>x;
     cout<< x;
     return 0;
 }