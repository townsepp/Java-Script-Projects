
var scene = new THREE.Scene();
//camera settings

var camera = new THREE.PerspectiveCamera(75,window.innerWidth/window.innerHeight,1,1000)
camera.position.z = 0;
camera.position.x = 0;
camera.position.y = -1;
camera.rotation.set(Math.PI*0,Math.PI*0,Math.PI*0);
//renderer
var renderer = new THREE.WebGLRenderer({antialias: true});
renderer.setClearColor("#e5e5e5");
renderer.setSize(window.innerWidth,window.innerHeight);

document.body.appendChild(renderer.domElement);

window.addEventListener('resize', () => {
    renderer.setSize(window.innerWidth,window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;

    camera.updateProjectionMatrix();
})

var raycaster = new THREE.Raycaster();
var mouse = new THREE.Vector2(); 
//mesh components
var geometry = new THREE.BoxGeometry(1, 1, 1);



//bomb locations
var bombs=[] ;
for(var i=0;i<900;i++){
    var indicator=Math.random()+.15;
    var bomb;
     if(indicator>=1){
        bomb=true;
    }else {
        bomb=false;
    }
    bombs.push(bomb);
}
//set danger
var dangers=[];
//set dangers to 0
for(var i=0;i<30;i++){
    for(var j=0;j<30;j++){
        dangers.push(0);
}}
//add danger for each bomb
for(var i=0;i<30;i++){
    for(var j=0;j<30;j++){
        var bomb= bombs[i*30+j];
if(bomb==true){
    
    if(i==0&&j==0){
dangers[1]+=1;
dangers[30]+=1;
dangers[31]+=1
    }else if(i==29&&j==0){
        dangers[840]+=1;
        dangers[871]+=1;
        dangers[841]+=1
    }else if(i==0&&j==29){
        dangers[28]+=1;
        dangers[58]+=1;
        dangers[59]+=1
    }else if(i==29&&j==29){
        dangers[898]+=1;
        dangers[869]+=1;
        dangers[868]+=1
    }else if(i==0){
        dangers[i*30+j-1]+=1;
        dangers[i*30+j+1]+=1;
        dangers[(i+1)*30+j]+=1
        dangers[(i+1)*30+j+1]+=1;
        dangers[(i+1)*30+j-1]+=1;
        
    }else if(i==29){
        dangers[i*30+j-1]+=1;
        dangers[i*30+j+1]+=1;
        dangers[(i-1)*30+j]+=1
        dangers[(i-1)*30+j+1]+=1;
        dangers[(i-1)*30+j-1]+=1;
    }else if(j==0){
        dangers[i*30+j+1]+=1;
        dangers[(i-1)*30+j+1]+=1
        dangers[(i-1)*30+j]+=1
        dangers[(i+1)*30+j+1]+=1;
        dangers[(i+1)*30+j]+=1;
    }else if(j==29){
        dangers[i*30+j-1]+=1;
        dangers[(i-1)*30+j-1]+=1
        dangers[(i-1)*30+j]+=1
        dangers[(i+1)*30+j-1]+=1;
        dangers[(i+1)*30+j]+=1;
    }else {
        for(var k=i;k<i+3;k++){
            for(var l=j;l<j+3;l++){
        dangers[(k-1)*30+l-1]+=1;
    }}
    }
       

}

    }
}
//set scene
for(var i = 0; i<30;i++) {
    for(var  j= 0; j<30;j++) {
        var material = new THREE.MeshLambertMaterial({color: 0x333333});
    var mesh = new THREE.Mesh(geometry, material);

var bomb= bombs[i*30+j];
var danger= dangers[i*30+j];
    var trueColor;
    if(bomb==true){
        mesh.trueColor=0x000000;
    }else if(danger==0){
        mesh.trueColor=0x00ff00;
    }else if(danger==1){
        mesh.trueColor=0x0000ff;
    }else if(danger==2){
        mesh.trueColor=0xff0000;
    }else if(danger==3){
        mesh.trueColor=0x330000;
    }else if(danger==4){
        mesh.trueColor=0x660066
    }else if(danger==5){
        mesh.trueColor=0x220022;
    }

    mesh.position.x = i-15;
    mesh.position.y = -3;
    mesh.position.z = j-15;
    mesh.isbomb=bomb;
    mesh.dangerLvl=danger;
    scene.add(mesh);
    
}
}
//start opening spots

//lights in scene
/*var light = new THREE.PointLight(0xFFFFFF, 1, 1000)
light.position.set(0,0,0);
scene.add(light);

var light = new THREE.PointLight(0xFFFFFF, 2, 1000)
light.position.set(0,0,25);
scene.add(light);*/
var light = new THREE.PointLight(0xFFFFFF, 2, 1000)
light.position.set(-20,8,-20);
scene.add(light);
var light = new THREE.PointLight(0xFFFFFF, 2, 1000)
light.position.set(-20,8,20);
scene.add(light);
var light = new THREE.PointLight(0xFFFFFF, 2, 1000)
light.position.set(20,8,-20);
scene.add(light);
var light = new THREE.PointLight(0xFFFFFF, 2, 1000)
light.position.set(20,8,20);
scene.add(light);
var render = function() {
    requestAnimationFrame(render);


    renderer.render(scene, camera);
}
//move cubes
function onMouseMove(event) {
    event.preventDefault();

    mouse.x = ( event.clientX / window.innerWidth ) * 2 - 1;
    mouse.y = - ( event.clientY / window.innerHeight ) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);

    var intersects = raycaster.intersectObjects(scene.children, true);
    
        var randx=(Math.random()-.5)*7;
        var randy=(Math.random()-.5)*7;
        var randz=(Math.random()-.5)*7;
        //camera.position.set(intersects[i].object.x,5,intersects[i].object.z);
        //console.log(intersects[0].object.isbomb);
        //console.log(intersects[0].object.dangerLvl);
        //console.log(intersects[i].object.material.color.getColor);
        intersects[0].object.material.color.set(intersects[0].object.trueColor);
        this.tl = new TimelineMax();
        //this.tl.to(intersects[i].object.scale, .5, {x: 3, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.scale, .5, {x: 1, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.scale, .5, {y: 3, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.scale, .5, {y: 1, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.scale, .5, {z: 3, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.scale, .5, {z: 1, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.position, .5, {x: randx, ease: Expo.easeOut})
        this.tl.to(intersects[0].object.position, .5, {y: -2, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.position, .5, {z: randz, ease: Expo.easeOut})
        this.tl.to(intersects[0].object.rotation, .5, {y: Math.PI*.5, ease: Expo.easeOut}, "=-1.5")
        //this.tl.to(intersects[i].object.rotation, .5, {y: randy, ease: Expo.easeOut}, "=-1.5")
        this.tl.to(intersects[0].object.position, .5, {y: -3, ease: Expo.easeOut})
        //this.tl.to(intersects[i].object.rotation, .5, {z: Math.PI*.6, ease: Expo.easeOut}, "=-1.5")
    }
    function onmouseMove( event ) {

		if ( scope.isLocked === false ) return;

		var movementX = event.movementX || event.mozMovementX || event.webkitMovementX || 0;
		var movementY = event.movementY || event.mozMovementY || event.webkitMovementY || 0;

		euler.setFromQuaternion( camera.quaternion );

		euler.y -= movementX * 0.002;
		euler.x -= movementY * 0.002;

		euler.x = Math.max( PI_2 - scope.maxPolarAngle, Math.min( PI_2 - scope.minPolarAngle, euler.x ) );

		camera.quaternion.setFromEuler( euler );

		scope.dispatchEvent( changeEvent );

	}

    render();
    //renderer.domElement 
    //document.body
    





  //const  controls = new THREE.PointerLockControls(camera,renderer.domElement);
  




//key movement

var started=false
if(started==false){
var moveRight=false;
var moveLeft=false;
var moveForward=false;
var moveBack=false;
var angleRight=false;
var angleLeft=false;
var angleUp=false;
var angleDown=false;
var vertInc=false;
var vertDec=false;
started=true;
console.log(started);
}
//click to move
window.addEventListener('click', onMouseMove);
window.addEventListener('click', onmouseMove);
window.add
window.addEventListener('keydown', (e) => { 
    if (e.code === "KeyW")        moveForward=true
    else if (e.code === "KeyS") moveBack=true
    else if (e.code === "KeyD")        moveRight=true
    else if (e.code === "KeyA") moveLeft=true
    else if (e.code === "ArrowUp")        angleUp=true
    else if (e.code === "ArrowDown") angleDown=true
    else if (e.code === "ArrowRight")        angleRight=true
    else if (e.code === "ArrowLeft") angleLeft=true
    else if (e.code === "KeyR") vertInc=true
    else if (e.code === "KeyF") vertDec=true
  });
  
function animate(){
    
        if(moveRight==true){
        camera.position.x += .2;
      }
      if(moveLeft==true){
        camera.position.x -= .2;
      }
      if(moveForward==true){
        camera.position.z -= .2;
      }
      if(moveBack==true){
        camera.position.z += .2;
      }
      if(angleUp==true){
          
        
        camera.rotation.x+= Math.PI*.01;
      }
      if(angleDown==true){
     
        camera.rotation.x -= Math.PI*.01;
      }
      if(angleRight==true){
        camera.rotation.y -= Math.PI*.01;
        if(camera.rotation.y<0){
            camera.rotation.y+=2*Math.PI;
        }
      }
      if(angleLeft==true){
        camera.rotation.y += Math.PI*.01;
        if(camera.rotation.y>Math.PI*2){
            camera.rotation.y-=2*Math.PI;
        }
      }
      if(vertInc==true){
        camera.position.y += .2;
      }
      if(vertDec==true){
        camera.position.y -= .2;
      }
      requestAnimationFrame(animate);
    }
animate();
  window.addEventListener('keyup', (e) => { 
    if (e.code === "KeyW")        moveForward=false
    else if (e.code === "KeyS") moveBack=false
    else if (e.code === "KeyD")        moveRight=false
    else if (e.code === "KeyA") moveLeft=false
    else if (e.code === "ArrowUp")        angleUp=false
    else if (e.code === "ArrowDown") angleDown=false
    else if (e.code === "ArrowRight")        angleRight=false
    else if (e.code === "ArrowLeft") angleLeft=false
    else if (e.code === "KeyR") vertInc=false
    else if (e.code === "KeyF") vertDec=false
  });
  
    


//mouse angle
/*
window.addEventListener('movementX', (e)=>{
    var x = e.clientX;
    console.log(x);

})*/

//first rotations
/*if(angleUp==true){
          
    camera.rotation.x += Math.PI*.01;
   
  }
  if(angleDown==true){
    camera.rotation.x -= Math.PI*.01;
  }
  if(angleRight==true){
    camera.rotation.y -= Math.PI*.01;
    if(camera.rotation.y<0){
        camera.rotation.y+=2*Math.PI;
    }
  }
  if(angleLeft==true){
    camera.rotation.y += Math.PI*.01;
    if(camera.rotation.y>Math.PI*2){
        camera.rotation.y-=2*Math.PI;
    }
  }*/


//render();



















